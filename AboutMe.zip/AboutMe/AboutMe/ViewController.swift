//
//  ViewController.swift
//  AboutMe
//
//  Created by John Padilla on 9/30/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

