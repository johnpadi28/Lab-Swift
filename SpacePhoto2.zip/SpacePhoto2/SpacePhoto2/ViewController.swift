//
//  ViewController.swift
//  SpacePhoto2
//
//  Created by Mike Collier on 11/10/20.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var copyrightLabel: UILabel!
    
    let photoInfoController = PhotoInfoController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        descriptionLabel.text = ""
        copyrightLabel.text = ""
        
        photoInfoController.fetchPhotoInfo { photoInfo in
            guard let photoInfo = photoInfo else { return }
            
            self.title = photoInfo.title
            self.descriptionLabel.text = photoInfo.description
            
            if let copyright = photoInfo.copyright {
                self.copyrightLabel.text = copyright
            } else {
                self.copyrightLabel.isHidden = true
            }
        }
    }
}
