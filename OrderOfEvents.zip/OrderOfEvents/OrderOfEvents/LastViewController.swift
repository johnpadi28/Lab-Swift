//
//  LastViewController.swift
//  OrderOfEvents
//
//  Created by John Padilla on 10/1/20.
//

import UIKit

class LastViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
