//
//  ViewController.swift
//  PersonalQuiz
//
//  Created by John Padilla on 10/5/20.
//

import UIKit

class IntroductionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue) {
        
        
    }

}

