//
//  CustomizeViewController.swift
//  Pizza Delivery
//
//  Created by John Padilla on 10/2/20.
//

import UIKit

class CustomizeViewController: UIViewController {
    


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
